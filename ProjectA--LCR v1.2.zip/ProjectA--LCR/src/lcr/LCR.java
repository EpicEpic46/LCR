package lcr;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class LCR {
	
	Scanner sc = new Scanner(System.in);
	Random rand = new Random();
	static ArrayList<Player> players = new ArrayList<Player>();
	private ArrayList<String> names = new ArrayList<String>(Arrays.asList("Ash","Brock","Misty","Jessie","James"));
	
	boolean running = true;
	int currentPlayer = -1;
	int centerChips = 0;
	int turns = 0;
	
	public LCR(int numPlayers, int chipsPer) {
		for (int i = 0; i < numPlayers; i++) {
			players.add(new Player(chipsPer,names.get(i)));
		}
		try {
			FileIO fileio = new FileIO();
			fileio.readData();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void run() {
		while (running) {
			if (GameRunner.PRINT_RESULTS_EVERY_ROUND) {
				for (int i = 0; i < players.size(); i++) {
					System.out.println(players.get(i).getName() + " has " + players.get(i).getChips() + " chips");
				}
			}
			if (gameOver()) {
				try {
					FileIO fileio = new FileIO();
					fileio.writeData();
				} catch (IOException e) {
					e.printStackTrace();
				}
				
				System.out.println("Play Again? (Y/N)");
				if (GameRunner.PLAY_FOREVER) {
					break;
				} else if (sc.next().equalsIgnoreCase("Y")) {
					break;
				} else {
					System.exit(0);
				}
			}
			// Reset to 0th player after 4th player's turn
			if (currentPlayer == GameRunner.PLAYER_COUNT-1) {
				currentPlayer = -1;
			}
			
			currentPlayer++;
			int rolls;
			if (players.get(currentPlayer).getChips() < 3) {
				rolls = players.get(currentPlayer).getChips();
			} else {
				rolls = 3;
			}
			executeRoll(rolls);
			turns++;
		}
		reset();
		run();
	}
	
	private void executeRoll(int n) {
		for (int i = 0; i < n; i++) {
			int roll = roll();
			switch (roll) { //roll a number of times = current player chipNum
			case 4: case 5: case 6: 
				break;
			case 1:
				left(players.get(currentPlayer));
				break;
			case 2: 
				center(players.get(currentPlayer));
				break;
			case 3: 
				right(players.get(currentPlayer));
				break;
			}
		}
	}
	
	private int roll() {
		int roll = rand.nextInt(6) + 1;
		return roll;
	}
	
	private void left(Player p) { //adjusted
		if (currentPlayer == 0) {
			players.get(currentPlayer).giveChip(players.get(players.size()-1));
			if (GameRunner.PRINT_RESULTS_EVERY_ROUND) System.out.println("Player " + players.get(currentPlayer).getName() + " gave " + players.get(players.size()-1).getName() + " a chip!");
		} else {
			players.get(currentPlayer).giveChip(players.get(currentPlayer-1));
			if (GameRunner.PRINT_RESULTS_EVERY_ROUND) System.out.println("Player " + players.get(currentPlayer).getName() + " gave " + players.get(currentPlayer-1).getName() + " a chip!");
		}
	}
	private void center(Player p) {
		centerChips++;
		players.get(currentPlayer).loseChip();
		if (GameRunner.PRINT_RESULTS_EVERY_ROUND) System.out.println("Player " + players.get(currentPlayer).getName() + " gave a chip to the center!");
	}
	private void right(Player p) {
		if (currentPlayer == players.size()-1) {
			players.get(currentPlayer).giveChip(players.get(0));
			if (GameRunner.PRINT_RESULTS_EVERY_ROUND) System.out.println("Player " + players.get(currentPlayer).getName() + " gave " + players.get(0).getName() + " a chip!");
		} else {
			players.get(currentPlayer).giveChip(players.get(currentPlayer+1));
			if (GameRunner.PRINT_RESULTS_EVERY_ROUND) System.out.println("Player " + players.get(currentPlayer).getName() + " gave " + players.get(currentPlayer+1).getName() + " a chip!");
		}
	}
	/*
	 LEGACY CODE
	private void leftFirst(Player p) {
		players.get(currentPlayer).giveChip(players.get(currentPlayer-1)); //watch bounds of Array
	}
	private void rightFirst(Player p) {
		players.get(currentPlayer).giveChip(players.get(currentPlayer+1)); //watch bounds of Array
	}
	 */
	private void reset() {
		for (int i = 0; i < players.size(); i++) {
			players.get(i).setChips(GameRunner.CHIPS_PER_PLAYER);
		}
		turns = 0;
		currentPlayer = -1;
	}
	
	public boolean gameOver() {
		int count = 0;
		for (int i = 0; i < players.size(); i++) {
			if (players.get(i).getChips() > 0) {
				count ++;
			}
		}
		if (count < 2) {
			for (int i = 0; i < players.size(); i++) {
				if (players.get(i).getChips() > 0) {
					players.get(i).setWins(players.get(i).getWins()+1);
					System.out.println(players.get(i).getName() + " wins after " + turns + " turns!");
					System.out.println(players.get(i).getName() + " has won " + players.get(i).getWins() + " times!");
				} else {
					players.get(i).setLosses(players.get(i).getLosses()+1);
				}
			}
			return true;
		} else {
			return false;
		}
	}
}
