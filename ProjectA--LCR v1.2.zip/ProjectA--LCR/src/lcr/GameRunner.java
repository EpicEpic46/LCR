package lcr;

public class GameRunner {
	
	// To change player count from 5, you must also edit the names arrayList under LCR class
	final static int PLAYER_COUNT = 5;
	
	final static int CHIPS_PER_PLAYER = 5;
	
	// Said to do this in rubric, but steinke's in-class example showed otherwise, 
	// so heres a boolean to choose yourself
	final static boolean PRINT_RESULTS_EVERY_ROUND = false;
	
	// Disables User Interaction and assumes yes to play again
	final static boolean PLAY_FOREVER = true;
	
	
	public static void main(String[] args) {
		LCR game = new LCR(PLAYER_COUNT, CHIPS_PER_PLAYER);
		System.out.println("Game Results:");
		game.run();
	}
}
