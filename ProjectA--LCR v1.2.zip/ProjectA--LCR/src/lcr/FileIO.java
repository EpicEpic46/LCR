package lcr;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;

public class FileIO {
	
	public FileIO() throws IOException  {}
	
	// if using bluej, set source to "", else use personalized directory
	String source_folder = "C:\\Users\\Administrator\\Desktop\\New folder\\Eclipse\\ProjectA--LCR\\src\\lcr\\";	
	
	File file = new File(source_folder + "LCR.txt");
	

	public void writeData() throws IOException {
		BufferedWriter bw = new BufferedWriter(new PrintWriter(file));
		for (int i = 0; i < LCR.players.size(); i++) {
			bw.write(LCR.players.get(i).getName());
			bw.write(":");
			// bufferedwriter has issues with writing ints, so cast to string using ""
			bw.write(""+ LCR.players.get(i).getWins());
			bw.write(":");
			bw.write(""+ LCR.players.get(i).getLosses());
			bw.write(System.getProperty("line.separator"));
		}
		bw.close();
	}	
	
	
	public void readData() throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(file));	
		String line = "";
		for (int i = 0; i < LCR.players.size(); i++) {
			line = br.readLine();
			String[] str = line.split(":");
			LCR.players.get(i).setWins(Integer.parseInt(str[1]));
			LCR.players.get(i).setLosses(Integer.parseInt(str[2]));
		}
		br.close();
	}	
}